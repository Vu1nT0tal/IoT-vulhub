#!/bin/sh

if test  "$#" -le "0" 
then
	echo "Usage:$0 line-numbers sleep_time"
        exit
fi

MESS="/var/log/messages"
TEMP="/tmp/.messages"

until false
do
	if test -f $MESS ; then
		tail -n $1 $MESS > $TEMP
		cat $TEMP > $MESS
		rm -f $TEMP
	fi
	if test -z "$2" ; then
		exit 0;
	else
		sleep $2;
	fi
done
