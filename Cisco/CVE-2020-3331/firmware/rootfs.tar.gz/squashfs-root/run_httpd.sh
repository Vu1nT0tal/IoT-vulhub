ifconfig eth0 192.168.2.2/24
echo 0 > /proc/sys/kernel/randomize_va_space
chroot . /bin/sh -c 'LD_PRELOAD=./libnvram-faker.so /usr/sbin/httpd'